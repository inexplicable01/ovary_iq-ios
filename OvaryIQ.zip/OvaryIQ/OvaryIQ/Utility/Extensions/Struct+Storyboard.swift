//
//  Struct+Storyboard.swift
//  OvaryIQ
//
//  Created by Mobcoder on 19/01/22.
//

import Foundation
import UIKit
struct Storyboard {
   static let Auth = UIStoryboard(name: "Auth", bundle: nil)
   static let Questions = UIStoryboard(name: "Questions", bundle: nil)
   static let Home = UIStoryboard(name: "Home", bundle: nil)
}
