//
//  UIViewController.swift
//  OvaryIQ
//
//  Created by Mobcoder on 24/01/22.
//

import Foundation
import UIKit
//extension UIViewController {
//    // MARK: - Logout  Function
//     func logOutPopUp() {
//        // create the alert
//         let alert = UIAlertController(title: Text.appName.localizedString, message: Text.logOut.localizedString, preferredStyle: UIAlertController.Style.alert)
//
//    // add an action (button)
//         alert.addAction(UIAlertAction.init(title: Text.oks.localizedString,style: UIAlertAction.Style.default,handler: { (action) in
//            // Helper.LogoutApiHit()
//             Helper.showLoginScreen()
//    }))
//         alert.addAction(UIAlertAction.init(title: Text.cancel.localizedString, style: UIAlertAction.Style.default, handler: { (action) in
//
//    }))
//    self.present(alert, animated: true, completion: nil)
//   }
//}
