//
//  TryingGetPregnantViewModel.swift
//  OvaryIQ
//
//  Created by Mobcoder on 04/02/22.
//

import Foundation
class TryingGetPregnantViewModel {
}
