//
//  PredictedPeriodCVC.swift
//  OvaryIQ
//
//  Created by Mobcoder on 24/02/22.
//

import UIKit

class PredictedPeriodOtionsCVC: BaseCollectionViewCell {

}
