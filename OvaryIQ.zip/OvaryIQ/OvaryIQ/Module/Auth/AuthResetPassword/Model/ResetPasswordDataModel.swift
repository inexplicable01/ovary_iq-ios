//
//  ResetPasswordDataMdoel.swift
//  OvaryIQ
//
//  Created by Mobcoder on 07/02/22.
//

import Foundation
// MARK: - WelcomeData
struct ResetPasswordDataModel: Codable {
    let message: String?
    let data: UserDataModel?
}
